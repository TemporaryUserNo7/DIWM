from . import gan
from . import lenet
from . import resnet_8x
from . import segmentation